import os
import requests
import time
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict

# ==== Settings ====
BINANCE_API = "https://api.binance.com"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN_15MIN")  # Different bot for 15min
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
PUMP_THRESHOLD = 2.0  # percent (changed from 2.9 to 2.0)
RSI_PERIOD = 14  # standard RSI period
reported = set()  # avoid duplicate (symbol, timeframe)

CUSTOM_TICKERS = [
    "At","A2Z","ACE","ACH","ACT","ADA","ADX","AGLD","AIXBT","Algo","ALICE","ALPINE","ALT","AMP","ANKR","APE",
    "API3","APT","AR","ARB","ARDR","Ark","ARKM","ARPA","ASTR","Ata","ATOM","AVA","AVAX","AWE","AXL","BANANA",
    "BAND","BAT","BCH","BEAMX","BICO","BIO","Blur","BMT","Btc","CELO","Celr","CFX","CGPT","CHR","CHZ","CKB",
    "COOKIE","Cos","CTSI","CVC","Cyber","Dash","DATA","DCR","Dent","DeXe","DGB","DIA","DOGE","DOT","DUSK",
    "EDU","EGLD","ENJ","ENS","EPIC","ERA","ETC","ETH","FET","FIDA","FIL","fio","Flow","Flux","Gala","Gas",
    "GLM","GLMR","GMT","GPS","GRT","GTC","HBAR","HEI","HIGH","Hive","HOOK","HOT","HYPER","ICP","ICX","ID",
    "IMX","INIT","IO","IOST","IOTA","IOTX","IQ","JASMY","Kaia","KAITO","KSM","la","layer","LINK","LPT","LRC",
    "LSK","LTC","LUNA","MAGIC","MANA","Manta","Mask","MDT","ME","Metis","Mina","MOVR","MTL","NEAR","NEWT",
    "NFP","NIL","NKN","NTRN","OM","ONE","ONG","OP","ORDI","OXT","PARTI","PAXG","PHA","PHB","PIVX","Plume",
    "POL","POLYX","POND","Portal","POWR","Prom","PROVE","PUNDIX","Pyth","QKC","QNT","Qtum","RAD","RARE",
    "REI","Render","REQ","RIF","RLC","Ronin","ROSE","Rsr","RVN","Saga","SAHARA","SAND","SC","SCR","SCRT",
    "SEI","SFP","SHELL","Sign","SKL","Sol","SOPH","Ssv","Steem","Storj","STRAX","STX","Sui","SXP","SXT",
    "SYS","TAO","TFUEL","Theta","TIA","TNSR","TON","TOWNS","TRB","TRX","TWT","Uma","UTK","Vana","VANRY",
    "VET","VIC","VIRTUAL","VTHO","WAXP","WCT","win","WLD","Xai","XEC","XLM","XNO","XRP","XTZ","XVG","Zec",
    "ZEN","ZIL","ZK","ZRO","0G","2Z","C","D","ENSO","G","HOLO","KITE","LINEA","MIRA","OPEN","S","SAPIEN",
    "SOMI","W","WAL","XPL","ZBT","ZKC"
]

# ==== Session ====
session = requests.Session()
adapter = requests.adapters.HTTPAdapter(pool_connections=50, pool_maxsize=50, max_retries=2)
session.mount("https://", adapter)

# ==== Telegram ====
def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        requests.post(url, data={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": msg,
            "parse_mode": "HTML"
        }, timeout=60)
    except Exception as e:
        print("Telegram error:", e)

# ==== Utils ====
def format_volume(v):
    # Format volume as decimal millions (e.g., 1.40 for 1.40M, 0.36 for 360K)
    if v >= 1_000_000:
        return f"{v/1_000_000:.2f}"
    elif v >= 1_000:
        return f"{v/1_000_000:.2f}"
    else:
        return f"{v/1_000_000:.2f}"

def get_binance_server_time():
    try:
        return session.get(f"{BINANCE_API}/api/v3/time", timeout=60).json()["serverTime"] / 1000
    except:
        return time.time()

# ==== RSI Calculation ====
def calculate_rsi_with_full_history(closes, period=14):
    """
    Calculate RSI using ALL available historical data for proper RMA convergence.
    This matches TradingView/Binance exactly because RMA needs full history to converge properly.
    
    TradingView uses: RSI = 100 - (100 / (1 + RS))
    Where RS = RMA(gains, period) / RMA(losses, period)
    """
    if len(closes) < period + 1:
        return None
    
    # Calculate all price changes
    changes = [closes[i] - closes[i-1] for i in range(1, len(closes))]
    
    # Separate gains and losses
    gains = [max(change, 0) for change in changes]
    losses = [max(-change, 0) for change in changes]
    
    # Calculate initial RMA using SMA of first 'period' values
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    # Apply Wilder's smoothing (RMA) to ALL remaining values
    # This is the key - we need to smooth through ALL data, not just stop at period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    
    # Calculate final RSI
    if avg_loss == 0:
        return 100.0
    
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    
    return round(rsi, 2)

def calculate_rsi(candles, current_index, period=14):
    """
    Calculate RSI using RMA (Rolling Moving Average) - matches TradingView/Binance exactly.
    TradingView uses: RSI = 100 - (100 / (1 + RS))
    Where RS = RMA(gains, period) / RMA(losses, period)
    RMA is Wilder's smoothing method.
    """
    # Need at least period + 1 candles
    if current_index < period:
        return None
    
    # Get closing prices - we need period+1 closes to get period changes
    closes = [float(candles[i][4]) for i in range(current_index - period, current_index + 1)]
    
    if len(closes) < period + 1:
        return None
    
    # Calculate all price changes first
    changes = [closes[i] - closes[i-1] for i in range(1, len(closes))]
    
    # Separate into gains and losses
    gains = [max(change, 0) for change in changes]
    losses = [max(-change, 0) for change in changes]
    
    # Calculate RMA (Wilder's smoothing)
    # First value is SMA of first 'period' values
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    # Then apply smoothing for remaining values
    # RMA formula: (previous_RMA * (period-1) + current_value) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    
    # Calculate RS and RSI
    if avg_loss == 0:
        return 100.0
    
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    
    return round(rsi, 2)

# ==== Binance ====
def get_usdt_pairs():
    candidates = list(dict.fromkeys([t.upper() + "USDT" for t in CUSTOM_TICKERS]))
    try:
        data = session.get(f"{BINANCE_API}/api/v3/exchangeInfo", timeout=60).json()
        valid = {s["symbol"] for s in data["symbols"]
                 if s["quoteAsset"] == "USDT" and s["status"] == "TRADING"}
        pairs = [c for c in candidates if c in valid]
        print(f"Loaded {len(pairs)} valid USDT pairs.")
        return pairs
    except Exception as e:
        print("Exchange info error:", e)
        return []

def fetch_pump_candles(symbol, now_utc, start_time):
    try:
        # Fetch 15-minute candles (200 candles = 50 hours of data)
        url = f"{BINANCE_API}/api/v3/klines?symbol={symbol}&interval=15m&limit=200"
        candles = session.get(url, timeout=60).json()
        if not candles or isinstance(candles, dict):
            return []

        results = []
        
        # First pass: identify all pump indices
        pump_indices = []
        for i in range(1, len(candles)):
            prev_close = float(candles[i-1][4])
            close = float(candles[i][4])
            pct = ((close - prev_close) / prev_close) * 100
            if pct >= PUMP_THRESHOLD:
                pump_indices.append(i)
        
        # Second pass: process pumps in our time window
        for i, c in enumerate(candles):
            candle_time = datetime.fromtimestamp(c[0]/1000, tz=timezone.utc)
            if candle_time < start_time or candle_time >= now_utc - timedelta(minutes=15):
                continue

            # Skip first candle as we need previous close for percentage calculation
            if i == 0:
                continue

            prev_close = float(candles[i-1][4])
            open_p = float(c[1])
            high = float(c[2])
            low = float(c[3])
            close = float(c[4])
            volume = float(c[5])
            vol_usdt = open_p * volume

            # Calculate percentage change from previous close to current close (Binance method)
            pct = ((close - prev_close) / prev_close) * 100
            
            # Only process if this is a pump
            if pct < PUMP_THRESHOLD:
                continue
            
            # Calculate candles since last pump
            # Find previous pump before current index
            prev_pumps = [idx for idx in pump_indices if idx < i]
            if prev_pumps:
                last_pump_index = prev_pumps[-1]
                candles_since_last = i - last_pump_index
            else:
                # No previous pump found in history
                candles_since_last = 200  # Max history we have

            ma_start = max(0, i - 19)
            ma_vol = [
                float(candles[j][1]) * float(candles[j][5])
                for j in range(ma_start, i + 1)
            ]
            ma = sum(ma_vol) / len(ma_vol)
            vm = vol_usdt / ma if ma > 0 else 1.0

            # === Calculate RSI ===
            # Use ALL candles up to current index for proper RMA convergence
            if i >= RSI_PERIOD:
                all_closes = [float(candles[j][4]) for j in range(0, i + 1)]
                rsi = calculate_rsi_with_full_history(all_closes, RSI_PERIOD)
            else:
                rsi = None

            # === Prices ===
            buy = (open_p + close) / 2
            sell = buy * 1.022
            sl = buy * 0.99

            hour = candle_time.strftime("%Y-%m-%d %H:%M")
            results.append((symbol, pct, close, buy, sell, sl, hour, vol_usdt, vm, rsi, candles_since_last))

        return results
    except Exception as e:
        print(f"{symbol} error:", e)
        return []

def check_pumps(symbols):
    now_utc = datetime.now(timezone.utc)
    # For 15min candles, look back 12 hours instead of 1 day
    start_time = now_utc - timedelta(hours=12)
    pumps = []

    with ThreadPoolExecutor(max_workers=60) as ex:
        for f in as_completed([ex.submit(fetch_pump_candles, s, now_utc, start_time) for s in symbols]):
            pumps.extend(f.result() or [])

    return pumps

def check_pumps_lower_threshold(symbols):
    """Check for pumps with lower 2.0% threshold for Bot 1 backup"""
    now_utc = datetime.now(timezone.utc)
    start_time = (now_utc - timedelta(days=1)).replace(hour=22, minute=0, second=0, microsecond=0)
    pumps = []
    
    # Temporarily change threshold to 2.0%
    global PUMP_THRESHOLD
    original_threshold = PUMP_THRESHOLD
    PUMP_THRESHOLD = 2.0

    with ThreadPoolExecutor(max_workers=60) as ex:
        for f in as_completed([ex.submit(fetch_pump_candles, s, now_utc, start_time) for s in symbols]):
            pumps.extend(f.result() or [])
    
    # Restore original threshold
    PUMP_THRESHOLD = original_threshold
    return pumps

def check_pumps_low_threshold(symbols):
    """Check pumps with lower threshold (2.0%) for Bot 1 fallback"""
    now_utc = datetime.now(timezone.utc)
    start_time = (now_utc - timedelta(days=1)).replace(hour=22, minute=0, second=0, microsecond=0)
    pumps = []

    with ThreadPoolExecutor(max_workers=60) as ex:
        for f in as_completed([ex.submit(fetch_pump_candles_low, s, now_utc, start_time) for s in symbols]):
            pumps.extend(f.result() or [])

    return pumps

def fetch_pump_candles_low(symbol, now_utc, start_time):
    """Same as fetch_pump_candles but with 2.0% threshold"""
    try:
        url = f"{BINANCE_API}/api/v3/klines?symbol={symbol}&interval=1h&limit=200"
        candles = session.get(url, timeout=60).json()
        if not candles or isinstance(candles, dict):
            return []

        results = []
        
        # First pass: identify all pump indices with 2.0% threshold
        pump_indices = []
        for i in range(1, len(candles)):
            prev_close = float(candles[i-1][4])
            close = float(candles[i][4])
            pct = ((close - prev_close) / prev_close) * 100
            if pct >= 2.0:  # Lower threshold
                pump_indices.append(i)
        
        # Second pass: process pumps in our time window
        for i, c in enumerate(candles):
            candle_time = datetime.fromtimestamp(c[0]/1000, tz=timezone.utc)
            if candle_time < start_time or candle_time >= now_utc - timedelta(minutes=15):
                continue

            if i == 0:
                continue

            prev_close = float(candles[i-1][4])
            open_p = float(c[1])
            high = float(c[2])
            low = float(c[3])
            close = float(c[4])
            volume = float(c[5])
            vol_usdt = open_p * volume

            pct = ((close - prev_close) / prev_close) * 100
            
            if pct < 2.0:  # Lower threshold
                continue
            
            # Calculate candles since last pump
            prev_pumps = [idx for idx in pump_indices if idx < i]
            if prev_pumps:
                last_pump_index = prev_pumps[-1]
                candles_since_last = i - last_pump_index
            else:
                candles_since_last = 200

            ma_start = max(0, i - 19)
            ma_vol = [
                float(candles[j][1]) * float(candles[j][5])
                for j in range(ma_start, i + 1)
            ]
            ma = sum(ma_vol) / len(ma_vol)
            vm = vol_usdt / ma if ma > 0 else 1.0

            # Calculate RSI
            if i >= RSI_PERIOD:
                all_closes = [float(candles[j][4]) for j in range(0, i + 1)]
                rsi = calculate_rsi_with_full_history(all_closes, RSI_PERIOD)
            else:
                rsi = None

            buy = (open_p + close) / 2
            sell = buy * 1.022
            sl = buy * 0.99

            hour = candle_time.strftime("%Y-%m-%d %H:%M")
            results.append((symbol, pct, close, buy, sell, sl, hour, vol_usdt, vm, rsi, candles_since_last))

        return results
    except Exception as e:
        print(f"{symbol} error:", e)
        return []

def format_report(fresh, duration):
    grouped = defaultdict(list)
    for p in fresh:
        grouped[p[6]].append(p)

    report = f"⏱ Scan: {duration:.2f}s\n\n"
    
    for h in sorted(grouped):
        items = sorted(grouped[h], key=lambda x: x[8], reverse=True)
        
        report += f"  ⏰ {h} UTC\n"
        
        for s, pct, c, b, se, sl, hour, v, vm, rsi, csince in items:
            sym = s.replace("USDT","")
            rsi_str = f"{rsi:.1f}" if rsi is not None else "N/A"
            
            # Show candles since last pump with leading zeros
            csince_str = f"{csince:03d}"
            
            # Build the line
            line = f"{sym:6s} {pct:5.2f} {rsi_str:>4s} {vm:4.1f} {format_volume(v):4s} {csince_str}"
            
            # Determine symbol based on RSI and csince
            if rsi:
                if rsi >= 66:
                    if csince >= 20:
                        symbol = "✅"  # RSI ≥66 AND 20+ candles
                    else:
                        symbol = "🔴"  # RSI ≥66 AND <20 candles
                elif rsi >= 50:
                    symbol = "🟢"  # RSI 50-65.99
                else:
                    symbol = "🟡"  # RSI <50
            else:
                symbol = "⚪"  # No RSI data
            
            report += f"{symbol} <code>{line}</code>\n"
        
        report += "\n"
    
    return report

# ==== Main ====
def main():
    symbols = get_usdt_pairs()
    if not symbols:
        return

    while True:
        start = time.time()
        pumps = check_pumps(symbols)
        duration = time.time() - start

        fresh = []
        for p in pumps:
            key = (p[0], p[6])
            if key not in reported:
                reported.add(key)
                fresh.append(p)

        if fresh:
            msg = format_report(fresh, duration)
            print(msg)
            send_telegram(msg[:4096])
        else:
            print("No pumps in last 15 minutes.")

        server = get_binance_server_time()
        # Wait until next 15-minute mark
        next_15min = ((server // 900) + 1) * 900  # 900 seconds = 15 minutes
        time.sleep(max(0, next_15min - server + 1))

if __name__ == "__main__":
    main()
